module.exports = {
    MONGO_PASSWORD:"villaverdecrack"
}